## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(echo = TRUE,comment = NA,warning=FALSE,fig.width=6,fig.height = 6, fig.align='center',out.width="70%")

## ----eval=FALSE---------------------------------------------------------------
# if(!require(devtools)) install.packages("devtools")
# devtools::install_github("cardiomoon/moonBook")
# devtools::install_github("cardiomoon/webr")

## ----message=FALSE------------------------------------------------------------
require(ggplot2)
require(moonBook)
require(webr)

## -----------------------------------------------------------------------------
PieDonut(acs,aes(pies=Dx,donuts=smoking))

## -----------------------------------------------------------------------------
PieDonut(acs,aes(Dx,smoking),ratioByGroup=FALSE)

## ----fig.show='hold',out.width='45%',fig.align='default'----------------------
PieDonut(acs,aes(Dx,smoking),selected=1,labelposition=0,title="labelposition=0")
PieDonut(acs,aes(Dx,smoking),selected=1,labelposition=1,title="labelposition=1")

## -----------------------------------------------------------------------------
PieDonut(acs,aes(Dx,smoking),explode=1)

## -----------------------------------------------------------------------------
PieDonut(acs,aes(Dx,smoking),explode=1,explodeDonut=TRUE)

## -----------------------------------------------------------------------------
PieDonut(acs,aes(Dx,smoking),explode=1,selected=c(3,6,9),explodeDonut=TRUE)

## -----------------------------------------------------------------------------
PieDonut(acs,aes(Dx,smoking),start=3*pi/2,explode=1,selected=c(3,6,9),explodeDonut=TRUE)

## -----------------------------------------------------------------------------
PieDonut(acs,aes(Dx,smoking),start=3*pi/2,explode=1,selected=c(3,6,9),explodeDonut=TRUE,title="Distribution of Smoking Status by Diagnosis")

## -----------------------------------------------------------------------------
PieDonut(acs,aes(Dx,smoking),r0=0,showPieName=FALSE)

## -----------------------------------------------------------------------------
PieDonut(acs,aes(Dx,smoking),r0=0.2,r1=0.8,r2=1.4,explode=1,start=pi/2,explodeDonut=TRUE)

## -----------------------------------------------------------------------------
PieDonut(acs,aes(Dx,smoking),ratioByGroup=FALSE)

## ----fig.show='hold',out.width='45%',fig.align='default'----------------------
browser=c("MSIE","Firefox","Chrome","Safari","Opera")
share=c(50,21.9,10.8,6.5,1.8)
df=data.frame(browser,share)
PieDonut(df,aes(browser,count=share),r0=0.7,start=3*pi/2,labelpositionThreshold=0.1)
PieDonut(df,aes(browser,count=share),r0=0.7,explode=c(1,4),start=3*pi/2)

## ----message=FALSE------------------------------------------------------------
require(dplyr)
df=mtcars %>% group_by(gear,carb) %>% summarize(n=n())
df

## -----------------------------------------------------------------------------
PieDonut(df,aes(gear,carb,count=n),explode=3,r1=0.9,explodeDonut=TRUE,title="Distribution of carburetors by gears",star=3*pi/2,labelposition=0)

## -----------------------------------------------------------------------------
PieDonut(mtcars,aes(gear,carb),explode=3,r1=0.9,explodeDonut=TRUE,title="Distribution of carburetors by gears",star=3*pi/2,labelposition=0)

